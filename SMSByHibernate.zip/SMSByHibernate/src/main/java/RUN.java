import Views.AdminMenu;

public class RUN {
    public static void main(String[] args) {
        AdminMenu.runMenu();
    }
}